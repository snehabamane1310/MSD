import 'dotenv/config';
import mongoose from 'mongoose';
import bcrypt from 'bcryptjs';
import {User,Course,Quiz} from './models.js';

await mongoose.connect(process.env.MONGODB_URI||'mongodb://127.0.0.1:27017/learnspace');

const email=(process.env.ADMIN_EMAIL||'admin@example.com').toLowerCase();
let admin=await User.findOne({email});
if(!admin){
  admin=await User.create({name:process.env.ADMIN_NAME||'LearnSpace Admin',email,
    password:await bcrypt.hash(process.env.ADMIN_PASSWORD||'ChangeMe123!',12),role:'admin'});
  console.log(`Created admin ${email}`);
}else console.log(`Admin ${email} already exists; unchanged.`);

const title='Web Development Foundations';
let course=await Course.findOne({title});
if(!course){
  course=await Course.create({title,
    description:'Get comfortable with the building blocks of the web. Replace this sample course with your own lessons.',
    category:'Development',level:'Beginner',instructor:admin._id,published:true,featured:true,
    thumbnail:'https://images.unsplash.com/photo-1498050108023-c5249f4df085?auto=format&fit=crop&w=1200&q=80',
    lessons:[{title:'Welcome to web development',description:'A first look at how websites work.',
      youtubeUrl:'https://www.youtube.com/watch?v=UB1O30fR-EE',duration:'12 min',preview:true,order:0}]});
  console.log('Created sample course');
}

if(!await Quiz.exists({course:course._id})){
  await Quiz.create({course:course._id,title:'Web basics quiz',passPercent:60,timeLimitMinutes:10,maxAttempts:3,questions:[
    {text:'Which language gives a web page its structure?',options:['HTML','CSS','SQL','Python'],correctIndex:0},
    {text:'Which language is mainly used to style a web page?',options:['HTML','CSS','Java','C'],correctIndex:1},
    {text:'Which of these runs in the browser to make pages interactive?',options:['JavaScript','MongoDB','Express','npm'],correctIndex:0}]});
  console.log('Created sample quiz');
}
await mongoose.disconnect();
